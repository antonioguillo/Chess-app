// Shared chrome + three screens (Home, Library, Detail)

const { useState, useMemo, useEffect, useRef, useCallback } = React;

// ─────────────────────────────────────────────────────────────
// Shared chrome
// ─────────────────────────────────────────────────────────────
function TopBar({ left, right, center }) {
  return (
    <div style={{
      display: 'flex', alignItems: 'center',
      padding: '6px 18px 10px',
      gap: 12, minHeight: 38,
    }}>
      <div style={{ minWidth: 28, display: 'flex' }}>{left}</div>
      <div style={{ flex: 1, display: 'flex', justifyContent: 'center' }}>{center}</div>
      <div style={{ minWidth: 28, display: 'flex', justifyContent: 'flex-end' }}>{right}</div>
    </div>
  );
}

function Wordmark({ size = 18 }) {
  return (
    <div style={{
      display: 'flex', alignItems: 'center', gap: 7,
    }}>
      <span style={{
        fontFamily: 'var(--serif)', fontStyle: 'italic',
        fontSize: size + 2, fontWeight: 500,
        color: 'var(--ink)', letterSpacing: 0.2,
      }}>Gambito</span>
    </div>
  );
}

function IconBtn({ children, onClick, active }) {
  return (
    <button onClick={onClick} style={{
      width: 34, height: 34, borderRadius: 17,
      background: active ? 'rgba(199,155,101,0.14)' : 'transparent',
      border: '1px solid ' + (active ? 'rgba(199,155,101,0.35)' : 'rgba(241,234,215,0.10)'),
      color: 'var(--ink-2)',
      display: 'flex', alignItems: 'center', justifyContent: 'center',
      cursor: 'pointer', padding: 0,
    }}>{children}</button>
  );
}

function Chip({ children, active, onClick, tone = 'default' }) {
  const palettes = {
    default: { bg: 'rgba(241,234,215,0.04)', bd: 'rgba(241,234,215,0.10)', fg: 'var(--ink-2)' },
    active:  { bg: 'rgba(199,155,101,0.16)', bd: 'rgba(199,155,101,0.45)', fg: 'var(--gold)' },
    copper:  { bg: 'rgba(199,155,101,0.10)', bd: 'rgba(199,155,101,0.28)', fg: 'var(--copper)' },
  };
  const p = active ? palettes.active : palettes[tone];
  return (
    <button onClick={onClick} style={{
      padding: '6px 11px', borderRadius: 999,
      background: p.bg, border: '1px solid ' + p.bd, color: p.fg,
      fontSize: 11, fontWeight: 600,
      letterSpacing: 0.3,
      cursor: onClick ? 'pointer' : 'default',
      display: 'inline-flex', alignItems: 'center', gap: 6,
      fontFamily: 'var(--sans)',
    }}>{children}</button>
  );
}

function Popularity({ value, size = 5 }) {
  return (
    <div style={{ display: 'inline-flex', gap: 3 }}>
      {[1,2,3,4,5].map(i => (
        <div key={i} style={{
          width: size, height: size, borderRadius: size,
          background: i <= value ? 'var(--copper)' : 'rgba(241,234,215,0.13)',
        }} />
      ))}
    </div>
  );
}

function ColorDot({ color }) {
  // 'Blancas' or 'Negras'
  const isWhite = color === 'Blancas';
  return (
    <span style={{
      width: 9, height: 9, borderRadius: 9,
      background: isWhite ? '#f4ecd6' : '#15110b',
      border: '1px solid ' + (isWhite ? 'rgba(0,0,0,0.4)' : 'rgba(241,234,215,0.35)'),
      display: 'inline-block',
    }} />
  );
}

function Divider({ style }) {
  return <div style={{ height: 1, background: 'var(--line)', ...style }} />;
}

function SectionLabel({ roman, title, subtitle }) {
  return (
    <div style={{ display: 'flex', alignItems: 'baseline', gap: 12 }}>
      {roman && (
        <span style={{
          fontFamily: 'var(--serif)', fontStyle: 'italic',
          fontSize: 26, color: 'var(--copper)', lineHeight: 1,
          width: 28, textAlign: 'center',
        }}>{roman}</span>
      )}
      <div>
        <div style={{ fontFamily: 'var(--serif)', fontSize: 19, fontWeight: 500, lineHeight: 1.1, color: 'var(--ink)' }}>{title}</div>
        {subtitle && <div className="mono" style={{ fontSize: 10.5, color: 'var(--ink-mute)', marginTop: 3, letterSpacing: 0.3 }}>{subtitle}</div>}
      </div>
    </div>
  );
}

function TabBar({ tab, setTab }) {
  const items = [
    { id: 'home',    label: 'Inicio',     icon: 'home' },
    { id: 'library', label: 'Biblioteca', icon: 'book' },
    { id: 'practice', label: 'Práctica',  icon: 'target' },
  ];
  return (
    <div style={{
      position: 'absolute', left: 0, right: 0, bottom: 0,
      paddingBottom: 26, paddingTop: 10,
      background: 'linear-gradient(180deg, rgba(15,13,10,0) 0%, rgba(15,13,10,0.95) 38%, #0f0d0a 60%)',
      zIndex: 30,
    }}>
      <div style={{
        margin: '0 16px',
        background: 'rgba(28,24,20,0.85)',
        backdropFilter: 'blur(20px) saturate(180%)',
        WebkitBackdropFilter: 'blur(20px) saturate(180%)',
        border: '1px solid rgba(241,234,215,0.08)',
        borderRadius: 22,
        padding: '6px',
        display: 'flex',
        boxShadow: '0 14px 40px rgba(0,0,0,0.6), inset 0 1px 0 rgba(255,255,255,0.04)',
      }}>
        {items.map(it => {
          const a = tab === it.id;
          return (
            <button key={it.id} onClick={() => setTab(it.id)} style={{
              flex: 1, padding: '8px 4px',
              background: a ? 'rgba(199,155,101,0.13)' : 'transparent',
              border: 'none', borderRadius: 16, cursor: 'pointer',
              color: a ? 'var(--gold)' : 'var(--ink-mute)',
              display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 3,
            }}>
              <TabIcon name={it.icon} active={a} />
              <span style={{ fontSize: 10, fontWeight: 600, letterSpacing: 0.3 }}>{it.label}</span>
            </button>
          );
        })}
      </div>
    </div>
  );
}

function TabIcon({ name, active }) {
  const c = active ? 'var(--gold)' : 'var(--ink-mute)';
  if (name === 'home') return (
    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke={c} strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round">
      <path d="M3 11.5 12 4l9 7.5"/><path d="M5 10v9h14v-9"/>
    </svg>
  );
  if (name === 'book') return (
    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke={c} strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round">
      <path d="M4 4.5A1.5 1.5 0 0 1 5.5 3H19v15H5.5A1.5 1.5 0 0 0 4 19.5v-15z"/><path d="M4 19.5A1.5 1.5 0 0 0 5.5 21H19"/>
    </svg>
  );
  if (name === 'target') return (
    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke={c} strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round">
      <circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="5"/><circle cx="12" cy="12" r="1.5" fill={c}/>
    </svg>
  );
  return null;
}

// ─────────────────────────────────────────────────────────────
// HOME
// ─────────────────────────────────────────────────────────────
function HomeScreen({ goToOpening, goToLibrary }) {
  const daily = OPENINGS.find(o => o.id === 'ruy-lopez');
  const recent = ['italian', 'sicilian', 'queens-gambit'].map(id => OPENINGS.find(o => o.id === id));

  return (
    <div data-screen-label="01 Home" style={{ paddingBottom: 110 }}>
      <TopBar
        left={<Wordmark />}
        right={
          <div style={{ display: 'flex', gap: 8 }}>
            <IconBtn>
              <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round"><circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/></svg>
            </IconBtn>
            <IconBtn>
              <span style={{ fontFamily: 'var(--serif)', fontSize: 14, fontStyle: 'italic' }}>A</span>
            </IconBtn>
          </div>
        }
      />

      {/* Editorial hero */}
      <div style={{ padding: '6px 22px 18px' }}>
        <div className="tab" style={{ color: 'var(--copper)', marginBottom: 8 }}>· Tomo I — Apertura del día</div>
        <h1 style={{
          fontFamily: 'var(--serif)', fontWeight: 500,
          fontSize: 38, lineHeight: 1.0, margin: 0,
          letterSpacing: -0.5, color: 'var(--ink)',
        }}>
          Estudia las<br/><em style={{ fontWeight: 400 }}>aperturas</em> que<br/>moldearon el ajedrez.
        </h1>
        <p style={{
          marginTop: 14, marginBottom: 0,
          fontSize: 13.5, lineHeight: 1.55, color: 'var(--ink-2)',
          maxWidth: 320,
        }}>
          Cinco siglos de teoría reunidos en doce líneas esenciales.
          Aprende a tu ritmo, una apertura cada día.
        </p>
      </div>

      {/* Daily opening card */}
      <div style={{ padding: '0 18px' }}>
        <button onClick={() => goToOpening(daily.id)} style={{
          width: '100%', padding: 0, background: 'transparent', border: 'none', cursor: 'pointer',
          textAlign: 'left',
        }}>
          <div style={{
            position: 'relative',
            background: 'linear-gradient(150deg, #221d18 0%, #15110d 100%)',
            border: '1px solid var(--line)',
            borderRadius: 18,
            overflow: 'hidden',
            padding: 18,
            display: 'flex', gap: 14,
            boxShadow: '0 18px 40px rgba(0,0,0,0.35)',
          }}>
            <div style={{ width: 120, flexShrink: 0 }}>
              <MiniBoard moves={daily.moves} ply={daily.moves.length} size={120} />
            </div>
            <div style={{ flex: 1, display: 'flex', flexDirection: 'column', justifyContent: 'space-between' }}>
              <div>
                <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginBottom: 4 }}>
                  <span className="mono" style={{ fontSize: 9.5, color: 'var(--copper)', letterSpacing: 0.5 }}>{daily.eco}</span>
                  <span style={{ color: 'var(--ink-faint)' }}>·</span>
                  <span className="tab" style={{ fontSize: 9, color: 'var(--ink-mute)' }}>{daily.familyLabel}</span>
                </div>
                <div style={{
                  fontFamily: 'var(--serif)', fontWeight: 500,
                  fontSize: 22, lineHeight: 1.05, color: 'var(--ink)',
                  marginBottom: 4,
                }}>{daily.name}</div>
                <div style={{ fontSize: 11.5, lineHeight: 1.4, color: 'var(--ink-mute)' }}>
                  {daily.tagline}
                </div>
              </div>
              <div style={{
                marginTop: 10, display: 'flex', alignItems: 'center', gap: 8,
                color: 'var(--gold)', fontSize: 11.5, fontWeight: 600,
              }}>
                Comenzar lección
                <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><path d="M5 12h14M13 5l7 7-7 7"/></svg>
              </div>
            </div>
          </div>
        </button>
      </div>

      {/* Progress strip */}
      <div style={{
        margin: '20px 18px 4px',
        padding: '14px 16px',
        background: 'var(--surface)',
        border: '1px solid var(--line)',
        borderRadius: 14,
        display: 'flex', justifyContent: 'space-between',
      }}>
        {[
          { v: '7', l: 'aprendidas' },
          { v: '12', l: 'en estudio' },
          { v: '23', l: 'racha · días' },
        ].map((s, i) => (
          <React.Fragment key={i}>
            {i > 0 && <div style={{ width: 1, background: 'var(--line)' }} />}
            <div style={{ flex: 1, textAlign: 'center' }}>
              <div style={{
                fontFamily: 'var(--serif)', fontSize: 26, fontWeight: 500,
                color: 'var(--ink)', lineHeight: 1,
              }}>{s.v}</div>
              <div className="tab" style={{ fontSize: 9, color: 'var(--ink-mute)', marginTop: 4 }}>{s.l}</div>
            </div>
          </React.Fragment>
        ))}
      </div>

      {/* Continue learning */}
      <div style={{ padding: '24px 18px 0' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', marginBottom: 10 }}>
          <h3 style={{
            margin: 0, fontFamily: 'var(--serif)',
            fontSize: 18, fontWeight: 500, color: 'var(--ink)',
          }}>Continúa donde lo dejaste</h3>
          <button onClick={goToLibrary} style={{
            background: 'transparent', border: 'none', color: 'var(--ink-mute)',
            fontSize: 11, cursor: 'pointer',
          }}>Ver todo</button>
        </div>
        <div style={{ display: 'flex', gap: 10, overflowX: 'auto', margin: '0 -18px', padding: '0 18px' }} className="scroll">
          {recent.map(o => (
            <button key={o.id} onClick={() => goToOpening(o.id)} style={{
              flexShrink: 0, width: 152,
              background: 'var(--surface)', border: '1px solid var(--line)',
              borderRadius: 14, padding: 12, cursor: 'pointer', textAlign: 'left',
              color: 'var(--ink)',
            }}>
              <div style={{ marginBottom: 10 }}>
                <MiniBoard moves={o.moves} ply={Math.min(4, o.moves.length)} size={128} />
              </div>
              <div className="mono" style={{ fontSize: 9, color: 'var(--copper)', letterSpacing: 0.4 }}>{o.eco}</div>
              <div style={{
                fontFamily: 'var(--serif)', fontSize: 15, fontWeight: 500,
                color: 'var(--ink)', marginTop: 2, lineHeight: 1.15,
              }}>{o.name}</div>
              <div style={{
                marginTop: 8, height: 3, borderRadius: 3,
                background: 'rgba(241,234,215,0.08)', overflow: 'hidden',
              }}>
                <div style={{ width: ['62%','38%','81%'][recent.indexOf(o)], height: '100%', background: 'var(--copper)' }} />
              </div>
            </button>
          ))}
        </div>
      </div>

      {/* Families */}
      <div style={{ padding: '28px 18px 0' }}>
        <h3 style={{
          margin: '0 0 14px', fontFamily: 'var(--serif)',
          fontSize: 18, fontWeight: 500, color: 'var(--ink)',
        }}>Explora por familia</h3>
        <div style={{ display: 'flex', flexDirection: 'column' }}>
          {FAMILIES.map((f, i) => {
            const count = OPENINGS.filter(o => o.family === f.id).length;
            return (
              <button key={f.id} onClick={goToLibrary} style={{
                padding: '14px 0', background: 'transparent', border: 'none', cursor: 'pointer',
                display: 'flex', alignItems: 'center', gap: 14,
                textAlign: 'left',
                borderTop: i === 0 ? 'none' : '1px solid var(--line)',
                color: 'var(--ink)',
              }}>
                <span style={{
                  fontFamily: 'var(--serif)', fontStyle: 'italic',
                  fontSize: 24, color: 'var(--copper)',
                  width: 28, textAlign: 'center',
                }}>{f.roman}</span>
                <div style={{ flex: 1 }}>
                  <div style={{ fontFamily: 'var(--serif)', fontSize: 17, fontWeight: 500, color: 'var(--ink)', lineHeight: 1.1 }}>{f.label}</div>
                  <div className="mono" style={{ fontSize: 10, color: 'var(--ink-mute)', marginTop: 3, letterSpacing: 0.3 }}>{f.subtitle}</div>
                </div>
                <span style={{ fontSize: 11, color: 'var(--ink-mute)' }}>{count}</span>
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" style={{ color: 'var(--ink-faint)' }}><path d="M9 6l6 6-6 6"/></svg>
              </button>
            );
          })}
        </div>
      </div>

      <div style={{ height: 30 }} />
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// LIBRARY
// ─────────────────────────────────────────────────────────────
function LibraryScreen({ goToOpening, filter, setFilter }) {
  const filters = [
    { id: 'all',       label: 'Todas' },
    { id: 'open',      label: 'Abiertas' },
    { id: 'semi-open', label: 'Semi-abiertas' },
    { id: 'closed',    label: 'Cerradas' },
    { id: 'indian',    label: 'Indias' },
    { id: 'flank',     label: 'Flanco' },
  ];

  const visibleFamilies = filter === 'all' ? FAMILIES : FAMILIES.filter(f => f.id === filter);

  return (
    <div data-screen-label="02 Library" style={{ paddingBottom: 110 }}>
      <TopBar
        left={
          <IconBtn>
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><path d="M3 6h18M3 12h18M3 18h18"/></svg>
          </IconBtn>
        }
        center={<span className="tab" style={{ color: 'var(--ink-mute)' }}>Biblioteca</span>}
        right={
          <IconBtn>
            <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round"><circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/></svg>
          </IconBtn>
        }
      />

      <div style={{ padding: '4px 22px 14px' }}>
        <h1 style={{
          fontFamily: 'var(--serif)', fontWeight: 500,
          fontSize: 36, lineHeight: 1, margin: 0,
          color: 'var(--ink)', letterSpacing: -0.5,
        }}>El <em style={{ fontWeight: 400 }}>repertorio</em></h1>
        <p style={{
          marginTop: 8, marginBottom: 0,
          fontSize: 12.5, lineHeight: 1.5, color: 'var(--ink-mute)',
        }}>
          Doce aperturas, ordenadas por familia clásica.
          Cada una con su historia, sus ideas y sus variantes principales.
        </p>
      </div>

      {/* Filter chips */}
      <div style={{
        display: 'flex', gap: 7, overflowX: 'auto',
        padding: '6px 18px 14px', margin: 0,
      }} className="scroll">
        {filters.map(f => (
          <Chip key={f.id} active={filter === f.id} onClick={() => setFilter(f.id)}>
            {f.label}
          </Chip>
        ))}
      </div>

      {/* Family sections */}
      <div style={{ padding: '0 18px' }}>
        {visibleFamilies.map((f, fi) => {
          const items = OPENINGS.filter(o => o.family === f.id);
          if (!items.length) return null;
          return (
            <div key={f.id} style={{ marginBottom: 22 }}>
              <div style={{ marginBottom: 12, marginTop: fi === 0 ? 4 : 16, display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                <SectionLabel roman={f.roman} title={f.label} subtitle={f.subtitle} />
                <span className="mono" style={{ fontSize: 10, color: 'var(--ink-faint)' }}>{items.length.toString().padStart(2,'0')}</span>
              </div>
              <div style={{
                background: 'var(--surface)',
                border: '1px solid var(--line)',
                borderRadius: 14,
                overflow: 'hidden',
              }}>
                {items.map((o, i) => (
                  <button key={o.id} onClick={() => goToOpening(o.id)} style={{
                    width: '100%',
                    display: 'flex', alignItems: 'center', gap: 12,
                    padding: '12px 14px',
                    background: 'transparent', border: 'none', cursor: 'pointer',
                    borderTop: i === 0 ? 'none' : '1px solid var(--line-soft)',
                    color: 'var(--ink)', textAlign: 'left',
                  }}>
                    <div style={{ width: 50, height: 50, flexShrink: 0, borderRadius: 4, overflow: 'hidden' }}>
                      <MiniBoard moves={o.moves} ply={Math.min(o.moves.length, 5)} size={50} />
                    </div>
                    <div style={{ flex: 1, minWidth: 0 }}>
                      <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginBottom: 3 }}>
                        <ColorDot color={o.color} />
                        <span className="mono" style={{ fontSize: 9, color: 'var(--ink-mute)', letterSpacing: 0.4 }}>{o.eco}</span>
                      </div>
                      <div style={{ fontFamily: 'var(--serif)', fontSize: 16, fontWeight: 500, lineHeight: 1.1, color: 'var(--ink)' }}>{o.name}</div>
                      <div style={{ fontSize: 11, color: 'var(--ink-mute)', marginTop: 3, lineHeight: 1.35, overflow: 'hidden', textOverflow: 'ellipsis', display: '-webkit-box', WebkitLineClamp: 1, WebkitBoxOrient: 'vertical' }}>{o.tagline}</div>
                    </div>
                    <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'flex-end', gap: 6 }}>
                      <Popularity value={o.popularity} />
                      <span className="mono" style={{ fontSize: 9, color: 'var(--ink-faint)', letterSpacing: 0.3 }}>{o.difficulty.toUpperCase()}</span>
                    </div>
                  </button>
                ))}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// DETAIL
// ─────────────────────────────────────────────────────────────
function DetailScreen({ opening, goBack }) {
  const [ply, setPly] = useState(0);
  const [playing, setPlaying] = useState(false);
  const moves = opening.moves;
  const total = moves.length;
  const currentMove = ply > 0 ? moves[ply - 1] : null;

  // Auto-play
  useEffect(() => {
    if (!playing) return;
    if (ply >= total) { setPlaying(false); return; }
    const t = setTimeout(() => setPly(p => Math.min(total, p + 1)), 1100);
    return () => clearTimeout(t);
  }, [playing, ply, total]);

  // Reset when opening changes
  useEffect(() => { setPly(0); setPlaying(false); }, [opening.id]);

  // Build move pair display
  const movePairs = useMemo(() => {
    const pairs = [];
    for (let i = 0; i < moves.length; i += 2) {
      pairs.push({ num: i/2 + 1, white: moves[i], black: moves[i+1] || null, whiteIdx: i, blackIdx: i+1 });
    }
    return pairs;
  }, [moves]);

  return (
    <div data-screen-label="03 Detail" style={{ paddingBottom: 120 }}>
      <TopBar
        left={
          <button onClick={goBack} style={{
            background: 'transparent', border: 'none', cursor: 'pointer',
            color: 'var(--ink-2)', display: 'flex', alignItems: 'center', gap: 4,
            padding: 0, fontSize: 13,
          }}>
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round"><path d="M15 6l-6 6 6 6"/></svg>
          </button>
        }
        center={<span className="tab" style={{ color: 'var(--ink-mute)' }}>Apertura · {opening.eco}</span>}
        right={
          <IconBtn>
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round"><path d="M5 12v7a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1v-7"/><path d="M12 3v13M7 8l5-5 5 5"/></svg>
          </IconBtn>
        }
      />

      {/* Editorial header */}
      <div style={{ padding: '0 22px 16px' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 6 }}>
          <ColorDot color={opening.color} />
          <span className="tab" style={{ fontSize: 9, color: 'var(--ink-mute)' }}>{opening.familyLabel}</span>
          <span style={{ color: 'var(--ink-faint)' }}>·</span>
          <span className="mono" style={{ fontSize: 10, color: 'var(--ink-mute)' }}>{opening.year}</span>
        </div>
        <h1 style={{
          fontFamily: 'var(--serif)', fontWeight: 500,
          fontSize: 32, lineHeight: 1.0, margin: 0,
          color: 'var(--ink)', letterSpacing: -0.4,
        }}>{opening.name}</h1>
        <div style={{
          fontFamily: 'var(--serif)', fontStyle: 'italic',
          fontSize: 14, color: 'var(--copper)', marginTop: 3,
        }}>{opening.spanish}</div>
      </div>

      {/* Board */}
      <div style={{ display: 'flex', justifyContent: 'center', padding: '0 16px' }}>
        <ChessBoard pieces={piecesAfter(moves, ply)} lastMove={currentMove} size={362} />
      </div>

      {/* Move pill row */}
      <div style={{ padding: '14px 22px 0', display: 'flex', alignItems: 'center', gap: 10 }}>
        <div style={{ flex: 1 }}>
          <div className="mono" style={{ fontSize: 9.5, color: 'var(--ink-faint)', letterSpacing: 0.4 }}>
            JUGADA {ply.toString().padStart(2,'0')} / {total.toString().padStart(2,'0')}
          </div>
          <div style={{
            fontFamily: 'var(--serif)', fontSize: 17, fontWeight: 500,
            color: ply === 0 ? 'var(--ink-mute)' : 'var(--ink)',
            marginTop: 2, fontStyle: ply === 0 ? 'italic' : 'normal',
          }}>
            {ply === 0 ? 'Posición inicial' : ((Math.ceil(ply/2)) + '. ' + (ply%2===1 ? '' : '… ') + currentMove.san)}
          </div>
        </div>
        <div style={{ display: 'flex', gap: 6 }}>
          <CtrlBtn onClick={() => { setPly(0); setPlaying(false); }} disabled={ply === 0}>
            <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><path d="M19 5v14M16 5l-9 7 9 7"/></svg>
          </CtrlBtn>
          <CtrlBtn onClick={() => { setPly(p => Math.max(0, p-1)); setPlaying(false); }} disabled={ply === 0}>
            <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><path d="M15 6l-6 6 6 6"/></svg>
          </CtrlBtn>
          <CtrlBtn primary onClick={() => {
            if (ply >= total) { setPly(0); setPlaying(true); }
            else setPlaying(p => !p);
          }}>
            {playing ? (
              <svg width="11" height="11" viewBox="0 0 24 24" fill="currentColor"><rect x="6" y="5" width="4" height="14"/><rect x="14" y="5" width="4" height="14"/></svg>
            ) : (
              <svg width="11" height="11" viewBox="0 0 24 24" fill="currentColor"><path d="M7 5v14l12-7z"/></svg>
            )}
          </CtrlBtn>
          <CtrlBtn onClick={() => { setPly(p => Math.min(total, p+1)); setPlaying(false); }} disabled={ply === total}>
            <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><path d="M9 6l6 6-6 6"/></svg>
          </CtrlBtn>
        </div>
      </div>

      {/* Current move note */}
      <div style={{ padding: '14px 22px 0' }}>
        <div style={{
          background: 'var(--surface)',
          border: '1px solid var(--line)',
          borderLeft: '2px solid var(--copper)',
          borderRadius: 4,
          padding: '12px 14px',
          minHeight: 60,
        }}>
          <div className="tab" style={{ fontSize: 9, color: 'var(--copper)', marginBottom: 4 }}>· Comentario</div>
          <div style={{
            fontFamily: 'var(--serif)', fontSize: 14, lineHeight: 1.45,
            color: 'var(--ink)',
          }}>
            {currentMove ? currentMove.note : 'Posición inicial. Pulsa ▷ para comenzar a reproducir la línea principal de la apertura.'}
          </div>
        </div>
      </div>

      {/* Move list */}
      <div style={{ padding: '20px 22px 0' }}>
        <div style={{ display: 'flex', alignItems: 'baseline', justifyContent: 'space-between', marginBottom: 10 }}>
          <h3 style={{ margin: 0, fontFamily: 'var(--serif)', fontSize: 17, fontWeight: 500, color: 'var(--ink)' }}>Línea principal</h3>
          <span className="mono" style={{ fontSize: 10, color: 'var(--ink-faint)' }}>NOTACIÓN ESPAÑOLA</span>
        </div>
        <div style={{
          background: 'var(--surface)',
          border: '1px solid var(--line)',
          borderRadius: 10,
          padding: '4px 6px',
          fontFamily: 'var(--mono)',
        }}>
          {movePairs.map((mp, i) => (
            <div key={i} style={{
              display: 'flex', alignItems: 'center', padding: '6px 6px',
              borderTop: i === 0 ? 'none' : '1px solid var(--line-soft)',
              gap: 8,
            }}>
              <span style={{ width: 22, fontSize: 11, color: 'var(--ink-faint)', textAlign: 'right' }}>{mp.num}.</span>
              <button onClick={() => { setPly(mp.whiteIdx + 1); setPlaying(false); }} style={{
                flex: 1, padding: '6px 10px', borderRadius: 6,
                background: ply === mp.whiteIdx + 1 ? 'rgba(199,155,101,0.18)' : 'transparent',
                border: '1px solid ' + (ply === mp.whiteIdx + 1 ? 'rgba(199,155,101,0.4)' : 'transparent'),
                color: ply >= mp.whiteIdx + 1 ? 'var(--ink)' : 'var(--ink-mute)',
                fontFamily: 'var(--mono)', fontSize: 12.5, fontWeight: 500,
                cursor: 'pointer', textAlign: 'left',
              }}>{mp.white.san}</button>
              {mp.black ? (
                <button onClick={() => { setPly(mp.blackIdx + 1); setPlaying(false); }} style={{
                  flex: 1, padding: '6px 10px', borderRadius: 6,
                  background: ply === mp.blackIdx + 1 ? 'rgba(199,155,101,0.18)' : 'transparent',
                  border: '1px solid ' + (ply === mp.blackIdx + 1 ? 'rgba(199,155,101,0.4)' : 'transparent'),
                  color: ply >= mp.blackIdx + 1 ? 'var(--ink)' : 'var(--ink-mute)',
                  fontFamily: 'var(--mono)', fontSize: 12.5, fontWeight: 500,
                  cursor: 'pointer', textAlign: 'left',
                }}>{mp.black.san}</button>
              ) : <div style={{ flex: 1 }} />}
            </div>
          ))}
        </div>
      </div>

      {/* History & Idea */}
      <div style={{ padding: '24px 22px 0' }}>
        <div className="tab" style={{ color: 'var(--copper)', marginBottom: 6 }}>· Historia</div>
        <p style={{
          margin: 0,
          fontFamily: 'var(--serif)', fontSize: 14.5, lineHeight: 1.55,
          color: 'var(--ink-2)',
        }}>{opening.description}</p>
      </div>

      <div style={{ padding: '20px 22px 0' }}>
        <div className="tab" style={{ color: 'var(--copper)', marginBottom: 6 }}>· Idea estratégica</div>
        <p style={{
          margin: 0,
          fontFamily: 'var(--serif)', fontSize: 14.5, lineHeight: 1.55,
          color: 'var(--ink-2)',
        }}>{opening.idea}</p>
      </div>

      {/* Meta footer */}
      <div style={{
        margin: '22px 22px 0',
        padding: '14px 0',
        borderTop: '1px solid var(--line)',
        borderBottom: '1px solid var(--line)',
        display: 'flex', justifyContent: 'space-between',
      }}>
        {[
          { l: 'Bando', v: opening.color },
          { l: 'Dificultad', v: opening.difficulty },
          { l: 'Popularidad', v: <Popularity value={opening.popularity} size={6} /> },
        ].map((m, i) => (
          <div key={i} style={{ textAlign: i === 0 ? 'left' : i === 2 ? 'right' : 'center', flex: 1 }}>
            <div className="tab" style={{ fontSize: 9, color: 'var(--ink-mute)', marginBottom: 5 }}>{m.l}</div>
            <div style={{ fontFamily: 'var(--serif)', fontSize: 13, fontStyle: 'italic', color: 'var(--ink)' }}>{m.v}</div>
          </div>
        ))}
      </div>

      <div style={{ height: 30 }} />
    </div>
  );
}

function CtrlBtn({ children, onClick, disabled, primary }) {
  return (
    <button onClick={onClick} disabled={disabled} style={{
      width: primary ? 40 : 32, height: 32, borderRadius: 16,
      background: primary
        ? (disabled ? 'rgba(199,155,101,0.2)' : 'linear-gradient(180deg, #d2a26d 0%, #a47a48 100%)')
        : 'transparent',
      border: '1px solid ' + (primary ? 'rgba(199,155,101,0.5)' : 'rgba(241,234,215,0.14)'),
      color: primary ? '#1a1410' : 'var(--ink-2)',
      cursor: disabled ? 'default' : 'pointer',
      display: 'flex', alignItems: 'center', justifyContent: 'center',
      opacity: disabled ? 0.4 : 1,
      padding: 0,
    }}>{children}</button>
  );
}

// ─────────────────────────────────────────────────────────────
// PRACTICE (small placeholder for the bottom tab)
// ─────────────────────────────────────────────────────────────
function PracticeScreen() {
  return (
    <div data-screen-label="04 Practice" style={{ paddingBottom: 120 }}>
      <TopBar
        left={<span style={{ width: 28 }} />}
        center={<span className="tab" style={{ color: 'var(--ink-mute)' }}>Práctica</span>}
        right={<span style={{ width: 28 }} />}
      />
      <div style={{ padding: '20px 22px' }}>
        <h1 style={{
          fontFamily: 'var(--serif)', fontWeight: 500,
          fontSize: 32, lineHeight: 1, margin: 0,
          color: 'var(--ink)',
        }}>Pon a prueba<br/><em style={{ fontWeight: 400 }}>lo aprendido</em></h1>
        <p style={{ marginTop: 12, fontSize: 13, lineHeight: 1.5, color: 'var(--ink-mute)' }}>
          Reproduce de memoria las líneas principales o resuelve las variantes características de cada apertura.
        </p>

        <div style={{ marginTop: 22, display: 'flex', flexDirection: 'column', gap: 12 }}>
          {[
            { t: 'Reproducir de memoria', s: 'Juega la línea principal sin pistas.', n: '12 ejercicios' },
            { t: 'Adivina la apertura', s: 'Identifica la apertura por la posición.', n: '24 ejercicios' },
            { t: 'Encuentra la jugada', s: 'Elige el movimiento característico.', n: '36 ejercicios' },
          ].map(c => (
            <div key={c.t} style={{
              background: 'var(--surface)', border: '1px solid var(--line)',
              borderRadius: 14, padding: 16,
              display: 'flex', alignItems: 'center', gap: 14,
            }}>
              <div style={{
                width: 44, height: 44, borderRadius: 22,
                background: 'rgba(199,155,101,0.13)',
                border: '1px solid rgba(199,155,101,0.3)',
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                color: 'var(--gold)',
                fontFamily: 'var(--serif)', fontStyle: 'italic', fontSize: 18,
              }}>♞</div>
              <div style={{ flex: 1 }}>
                <div style={{ fontFamily: 'var(--serif)', fontSize: 16, fontWeight: 500, color: 'var(--ink)' }}>{c.t}</div>
                <div style={{ fontSize: 11.5, color: 'var(--ink-mute)', marginTop: 2 }}>{c.s}</div>
                <div className="mono" style={{ fontSize: 9.5, color: 'var(--ink-faint)', marginTop: 4, letterSpacing: 0.3 }}>{c.n.toUpperCase()}</div>
              </div>
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" style={{ color: 'var(--ink-faint)' }}><path d="M9 6l6 6-6 6"/></svg>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

Object.assign(window, {
  HomeScreen, LibraryScreen, DetailScreen, PracticeScreen,
  TabBar, TopBar, Wordmark, Chip, Popularity, ColorDot, SectionLabel,
});
