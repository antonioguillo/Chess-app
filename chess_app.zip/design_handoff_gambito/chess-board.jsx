// Chess board + opening player

const FILES = ['a','b','c','d','e','f','g','h'];
const RANKS = ['1','2','3','4','5','6','7','8'];

const GLYPH = { K: '♚', Q: '♛', R: '♜', B: '♝', N: '♞', P: '♟' };

// Build initial piece array with stable IDs
function initialPieces() {
  const arr = [];
  let id = 0;
  for (const [sq, p] of Object.entries(INITIAL_POSITION)) {
    arr.push({ id: 'p' + (id++), type: p, square: sq, captured: false });
  }
  return arr;
}

// Apply a move ({from, to}) to a pieces array, returning a new array
function applyMove(pieces, move) {
  return pieces.map(p => {
    if (p.captured) return p;
    if (p.square === move.from) return { ...p, square: move.to };
    if (p.square === move.to)   return { ...p, captured: true };
    return p;
  });
}

// Replay the first N moves
function piecesAfter(moves, n) {
  let arr = initialPieces();
  for (let i = 0; i < n; i++) arr = applyMove(arr, moves[i]);
  return arr;
}

// ─────────────────────────────────────────────────────────────
// Piece glyph
// ─────────────────────────────────────────────────────────────
function Piece({ type, size }) {
  const color = type[0];
  const t = type[1];
  const isWhite = color === 'w';
  return (
    <span style={{
      fontSize: size,
      lineHeight: 1,
      color: isWhite ? '#f4ecd6' : '#15110b',
      textShadow: isWhite
        ? '0 1px 0 rgba(0,0,0,0.45), 0 0 1px rgba(0,0,0,0.6)'
        : '0 1px 0 rgba(255,255,255,0.08)',
      WebkitTextStroke: isWhite ? '0.6px rgba(20,15,8,0.55)' : '0.6px rgba(241,234,215,0.18)',
      userSelect: 'none',
      fontFamily: '"Segoe UI Symbol", "Apple Symbols", "DejaVu Sans", system-ui, sans-serif',
      display: 'inline-block',
      transform: 'translateY(-2%)',
    }}>{GLYPH[t]}</span>
  );
}

// ─────────────────────────────────────────────────────────────
// Chess board
// ─────────────────────────────────────────────────────────────
function ChessBoard({ pieces, lastMove, size = 320, showCoords = true, frame = true }) {
  const sq = size / 8;
  const squares = [];
  for (let ri = 7; ri >= 0; ri--) {
    for (let fi = 0; fi < 8; fi++) {
      const dark = (ri + fi) % 2 === 0;
      const name = FILES[fi] + RANKS[ri];
      const isLast = lastMove && (lastMove.from === name || lastMove.to === name);
      squares.push(
        <div key={name} style={{
          position: 'absolute',
          left: fi * sq, top: (7 - ri) * sq,
          width: sq, height: sq,
          background: dark ? 'var(--board-dark)' : 'var(--board-light)',
          boxShadow: dark ? 'inset 0 0 0 0.5px rgba(0,0,0,0.05)' : 'inset 0 0 0 0.5px rgba(0,0,0,0.02)',
        }}>
          {isLast && (
            <div style={{
              position: 'absolute', inset: 0,
              background: 'rgba(199, 155, 101, 0.42)',
              boxShadow: 'inset 0 0 0 1.5px rgba(199, 155, 101, 0.85)',
            }} />
          )}
          {showCoords && fi === 0 && (
            <span style={{
              position: 'absolute', left: 3, top: 2,
              fontSize: Math.max(8, sq * 0.18),
              fontFamily: 'var(--mono)', fontWeight: 600,
              color: dark ? 'rgba(241,234,215,0.55)' : 'rgba(30,22,14,0.5)',
            }}>{RANKS[ri]}</span>
          )}
          {showCoords && ri === 0 && (
            <span style={{
              position: 'absolute', right: 3, bottom: 1,
              fontSize: Math.max(8, sq * 0.18),
              fontFamily: 'var(--mono)', fontWeight: 600,
              color: dark ? 'rgba(241,234,215,0.55)' : 'rgba(30,22,14,0.5)',
            }}>{FILES[fi]}</span>
          )}
        </div>
      );
    }
  }

  return (
    <div style={{
      padding: frame ? 10 : 0,
      background: frame
        ? 'linear-gradient(160deg, #3a2818 0%, #20140c 100%)'
        : 'transparent',
      borderRadius: frame ? 6 : 0,
      boxShadow: frame
        ? '0 1px 0 rgba(255,255,255,0.06) inset, 0 24px 60px rgba(0,0,0,0.55), 0 4px 12px rgba(0,0,0,0.4)'
        : 'none',
      display: 'inline-block',
      lineHeight: 0,
    }}>
      <div style={{
        position: 'relative',
        width: size, height: size,
        background: '#000',
        boxShadow: 'inset 0 0 0 1px rgba(0,0,0,0.4)',
      }}>
        {squares}
        {/* pieces layer */}
        {pieces.filter(p => !p.captured).map(p => {
          const fi = p.square.charCodeAt(0) - 97;
          const ri = parseInt(p.square[1], 10) - 1;
          return (
            <div key={p.id} style={{
              position: 'absolute',
              left: 0, top: 0,
              width: sq, height: sq,
              transform: `translate(${fi * sq}px, ${(7 - ri) * sq}px)`,
              transition: 'transform 380ms cubic-bezier(.5,.05,.2,1)',
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              pointerEvents: 'none',
            }}>
              <Piece type={p.type} size={sq * 0.82} />
            </div>
          );
        })}
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// Mini board (static thumbnail showing position after N moves)
// ─────────────────────────────────────────────────────────────
function MiniBoard({ moves, ply = 0, size = 64 }) {
  const pieces = React.useMemo(() => piecesAfter(moves, ply), [moves, ply]);
  return <ChessBoard pieces={pieces} size={size} showCoords={false} frame={false} />;
}

// ─────────────────────────────────────────────────────────────
// Opening player — board + controls + move list
// ─────────────────────────────────────────────────────────────
function OpeningPlayer({ opening, ply, setPly }) {
  const pieces = React.useMemo(() => piecesAfter(opening.moves, ply), [opening, ply]);
  const lastMove = ply > 0 ? opening.moves[ply - 1] : null;
  const total = opening.moves.length;

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
      <div style={{ display: 'flex', justifyContent: 'center' }}>
        <ChessBoard pieces={pieces} lastMove={lastMove} size={345} />
      </div>
    </div>
  );
}

Object.assign(window, {
  ChessBoard, MiniBoard, OpeningPlayer, Piece,
  initialPieces, applyMove, piecesAfter,
  FILES, RANKS, GLYPH,
});
