# Handoff — Gambito: Chess Openings Learning App

## Overview
**Gambito** is a mobile app for learning chess openings. The user explores ~12 classic chess openings (Ruy López, Sicilian, French, Queen's Gambit, etc.) grouped by family, and learns each one by stepping through its main line on an interactive board with move-by-move commentary in Spanish.

The aesthetic is a deliberate hybrid: **classic chess-club elegance** (warm dark palette, serif editorial typography, Roman numerals for sections, italicized phrasing) meets **modern mobile UI** (rounded cards, glass tab bar, smooth piece-translate animations, generous whitespace).

Target user is a Spanish-speaking chess learner, beginner through intermediate.

## About the Design Files
The files in this bundle are **design references created in HTML/React (Babel-transpiled JSX, no build step)**. They are prototypes that demonstrate intended look, layout, motion and interaction — **not production code to copy verbatim**.

Your task is to **recreate these designs in the target codebase's existing environment** using its established patterns and libraries. If no environment exists yet:
- For iOS: **SwiftUI** is the natural fit (the design is iOS-first, uses iOS chrome conventions, and the typography/animation translates cleanly).
- For cross-platform: **React Native** or **Expo** with `react-native-reanimated` for the piece animations.
- For a web app: **Next.js / React** with `framer-motion` for animations.

Do not ship the bundled HTML directly. Re-implement using native components, the codebase's existing chess library if any (`chess.js` is recommended for move logic), and proper navigation primitives.

## Fidelity
**High-fidelity (hifi).** All colors, typography, spacing, animation timings and copy are final and should be recreated pixel-perfectly. The bundled `openings.jsx` file contains the **canonical opening dataset** (names, ECO codes, move sequences, commentary in Spanish) — copy this content as-is.

---

## Design Tokens

### Color palette (warm dark "chess-club")
```
--bg              #0f0d0a   /* primary background — very dark warm */
--bg-frame        #14110d   /* outer frame */
--surface         #1c1814   /* card backgrounds */
--surface-2       #221d18   /* elevated card backgrounds (hero) */
--line            #2a2520   /* visible borders */
--line-soft       #1f1a15   /* divider between list rows */

--ink             #f1ead7   /* primary text — warm cream */
--ink-2           #cdc2a8   /* body text */
--ink-mute        #8a8170   /* secondary / labels */
--ink-faint       #5a5447   /* tertiary / disabled */

--copper          #c79b65   /* primary accent — copper */
--copper-2        #a47a48   /* copper darker (button gradient end) */
--gold            #d9b87a   /* accent for active tab text */
--crimson         #a14a3c   /* reserved for warnings (unused so far) */

--board-light     #ddc8a3   /* light board squares */
--board-dark      #6e4f33   /* dark board squares */
--board-edge      #2d2118   /* board frame */
```

Accent on selected piece highlight: `rgba(199, 155, 101, 0.42)` fill + `rgba(199, 155, 101, 0.85)` inset border `1.5px`.

### Typography

| Role             | Family                                  | Weights used  | Notes                                  |
|------------------|-----------------------------------------|---------------|----------------------------------------|
| Display / serif  | `EB Garamond` (Google Fonts)            | 400, 500, 600 | All headlines, opening names, commentary |
| UI sans          | `Inter` (Google Fonts)                  | 400, 500, 600, 700 | Labels, buttons, body UI       |
| Notation / mono  | `JetBrains Mono` (Google Fonts)         | 400, 500, 600 | ECO codes, move list, "tab" small caps |

Typographic patterns:
- **Page titles**: EB Garamond 500, 32–38px, line-height 1.0, letter-spacing -0.4 to -0.5, with one word italicized (`<em style="font-weight:400">`) for editorial emphasis.
- **Section headers**: EB Garamond 500, 17–19px, often paired with an italic copper Roman numeral (24–26px italic) to the left.
- **Small caps / "tab" labels**: Inter 600, 9–11px, letter-spacing 0.14em (`text-transform: uppercase`), prefixed with a `·` (middle dot) in copper.
- **Body copy**: EB Garamond 14–14.5px, line-height 1.45–1.55, color `--ink-2`.
- **Move notation**: JetBrains Mono 12.5px, color steps from `--ink-mute` (not yet played) → `--ink` (played) → `--gold` (currently selected).

Use **Spanish chess notation**: knight = `C` (Caballo), bishop = `A` (Alfil), rook = `T` (Torre), queen = `D` (Dama), king = `R` (Rey).

### Spacing & radii
- Card padding: `14–18px`
- Card radius: `14–18px` (inset cards), `4–10px` (move list, comment box)
- Tab-bar pill radius: `22px`
- Button radius: `999px` (chips/pills) or `16–17px` (icon buttons)
- List row vertical padding: `12–14px`
- Section spacing: `20–28px` between major blocks

### Shadows
- Hero card: `0 18px 40px rgba(0,0,0,0.35)`
- Tab bar (floating glass): `0 14px 40px rgba(0,0,0,0.6), inset 0 1px 0 rgba(255,255,255,0.04)`
- Board frame: `0 1px 0 rgba(255,255,255,0.06) inset, 0 24px 60px rgba(0,0,0,0.55), 0 4px 12px rgba(0,0,0,0.4)`

### Iconography
All icons are **inline SVG, 1.7px stroke, round caps/joins, currentColor**. Sizes 14–18px. Examples in `screens.jsx`. Do not introduce an icon library — keep the bespoke set.

The chess pieces themselves are rendered as **Unicode glyphs** (`♔♕♖♗♘♙ ♚♛♜♝♞♟`) styled with a small text-stroke for contrast against the board. In a production app you should swap these for an SVG piece set (e.g. `cburnett` or `merida`) for cleaner rendering at all sizes, but match the visual weight.

---

## Screens

### 01 — Home / Inicio

**Purpose**: Daily entry point. Surface the "opening of the day", show progress, let user resume any in-progress opening, and offer family-based exploration.

**Layout (top → bottom, viewport ~393×782 inside iOS frame):**
1. **Top bar** (38px tall, 18px horizontal padding): wordmark "Gambito" italic serif left; search icon button + profile letter button right.
2. **Editorial hero** (22px horizontal padding):
   - Small-caps copper eyebrow `· TOMO I — APERTURA DEL DÍA`
   - 3-line headline (38px serif, "apertura" italicized): _"Estudia las apertura**s** que moldearon el ajedrez."_
   - Subtitle paragraph 13.5px, max-width 320px, color `--ink-2`.
3. **Daily-opening hero card** (18px horizontal):
   - Background gradient `linear-gradient(150deg, #221d18 0%, #15110d 100%)`, 1px `--line` border, radius 18, padding 18.
   - Left: 120×120 mini-board showing the **final position of the opening's main line**.
   - Right: ECO code (mono, copper) · familyLabel (small-caps muted) / opening name (22px serif) / tagline (11.5px muted) / CTA `Comenzar lección →` in gold.
4. **Progress strip** (3 stats, divider lines between):
   - "7 aprendidas", "12 en estudio", "23 racha · días"
   - Numbers in 26px serif, labels in small-caps 9px.
5. **"Continúa donde lo dejaste"** — horizontal scroll of 3 cards (152px wide each):
   - Each card: 128×128 mini-board (showing position after N plies), ECO code, opening name, copper progress bar.
6. **"Explora por familia"** — list of 5 rows separated by `--line`:
   - Italic copper Roman numeral (I–V) · family name (serif 17px) · subtitle in mono small caps · item count · chevron.
7. Bottom padding 110px to clear the floating tab bar.

**Data**: 12 openings from `openings.jsx`. "Daily" is hardcoded to `ruy-lopez` in the prototype; production should rotate by date (e.g. `openings[dayOfYear % openings.length]`).

### 02 — Library / Biblioteca

**Purpose**: Browse all openings grouped by family, filterable.

**Layout**:
1. **Top bar**: hamburger icon (left), `BIBLIOTECA` small-caps centered, search icon (right).
2. **Editorial header** (22px padding):
   - 36px serif title `El repertorio` (word "repertorio" italicized).
   - 12.5px muted subtitle.
3. **Filter chip row** — horizontal scroll, 7px gap:
   - Pills: `Todas / Abiertas / Semi-abiertas / Cerradas / Indias / Flanco`
   - Inactive: `rgba(241,234,215,0.04)` bg, `rgba(241,234,215,0.10)` border, `--ink-2` text.
   - Active: `rgba(199,155,101,0.16)` bg, `rgba(199,155,101,0.45)` border, `--gold` text.
4. **Family sections** (one per matching family):
   - Section label: italic copper Roman numeral + family name (19px serif) + mono subtitle, count on right (e.g. `02`).
   - List card: `--surface` bg, 1px `--line` border, 14px radius. Each row:
     - 50×50 mini-board (showing position after ~5 plies)
     - ColorDot (cream for "Blancas", near-black for "Negras") · ECO mono code
     - Opening name (16px serif), tagline truncated to 1 line
     - Right column: popularity dots (1–5 copper pills) + difficulty in mono caps (`PRINCIPIANTE` / `INTERMEDIO` / `AVANZADO`).

### 03 — Opening detail / Detalle

**Purpose**: Learn one opening — see its position evolve through the main line with commentary.

**Layout**:
1. **Top bar**: back chevron (left), `APERTURA · {ECO}` small-caps centered, share icon (right).
2. **Editorial header**:
   - ColorDot · familyLabel small-caps · year (mono).
   - 32px serif title (opening name).
   - 14px italic copper subtitle (Spanish alt name).
3. **Chess board**: 362px wide, framed (10px wood-tone padding), centered. The last-moved squares are highlighted with the copper translucent fill.
4. **Move pill row**:
   - Left: "JUGADA 02 / 07" small-caps mono + current move in serif italic when on starting position, otherwise upright (`3. Ab5` formatted with Spanish notation; black moves prefixed with `…`).
   - Right: 4 control buttons in a row — reset ⏮, prev ◁, **play/pause (primary, copper gradient)**, next ▷.
5. **Comment box** (`--surface` bg, **left-border 2px copper**, radius 4):
   - Small-caps copper "· Comentario" label.
   - Serif 14px commentary text from `opening.moves[ply-1].note`.
   - On starting position shows: _"Posición inicial. Pulsa ▷ para comenzar a reproducir la línea principal de la apertura."_
6. **Move list** ("Línea principal" + small caps "NOTACIÓN ESPAÑOLA"):
   - Card with rows of `{N. white  black}` pairs in mono 12.5px.
   - Each move is a click-target. Played moves use `--ink`, current move has copper-tinted bg + border, future moves use `--ink-mute`.
7. **Historia** section (serif paragraph in `--ink-2`).
8. **Idea estratégica** section (same treatment).
9. **Meta footer row** (3 stats, top + bottom `--line` borders): Bando / Dificultad / Popularidad (5 copper dots).

**Behavior**:
- `ply` state, range `0..moves.length`.
- Prev/next change `ply` by ±1, clamping. Reset → 0. Play toggles auto-advance.
- Auto-advance: each move plays after **1100ms**. Stops at end.
- Clicking any move in the list jumps directly to that ply.
- Switching to a different opening resets `ply=0` and `playing=false`.
- The chess board pieces are tracked as a stable array of `{id, type, square, captured}` — when a move is applied, the piece at `from.square` updates to `to.square` and any piece already on the destination is marked captured. **Stable IDs let CSS `transition: transform 380ms cubic-bezier(.5,.05,.2,1)` animate piece movement smoothly.** Replicate this: do NOT recreate piece DOM/views on each move.

### 04 — Practice / Práctica (placeholder)

A teaser screen with 3 exercise type cards (Reproducir de memoria / Adivina la apertura / Encuentra la jugada). Not implemented behaviorally — it's just a list of `--surface` cards with a small copper-tinted circular badge showing `♞`. Build out as needed.

---

## Global chrome

### Status bar / device frame
The HTML uses a custom iOS-26-style status bar (9:41, signal/wifi/battery icons) and dynamic island. **In a production iOS app, use the system status bar — do not redraw it.** The cream-on-dark scheme means status bar style should be `.lightContent`.

### Bottom tab bar (floating glass)
Three tabs: `Inicio`, `Biblioteca`, `Práctica`.

- Floats above content with a fade-to-bg gradient behind it (top of the bar fades from transparent to `--bg`).
- Pill container: 16px outer margin, 22px radius, `rgba(28,24,20,0.85)` bg with `backdrop-filter: blur(20px) saturate(180%)`, 1px `rgba(241,234,215,0.08)` border.
- Each tab: 8/4 padding, icon + 10px small-caps label.
- Active tab: `rgba(199,155,101,0.13)` bg pill inside, `--gold` icon stroke + label.
- Inactive: transparent bg, `--ink-mute` icon + label.
- **Hide the tab bar on the Detail screen** (full-screen reading mode).

---

## Interactions & Animations

| Element                  | Property                  | Value                                                |
|--------------------------|---------------------------|------------------------------------------------------|
| Piece movement on board  | `transform`               | `transition: 380ms cubic-bezier(.5,.05,.2,1)`         |
| Auto-play between moves  | timer                     | 1100ms per move                                       |
| Tab switch               | none / instant            | (acceptable to add 200ms cross-fade)                 |
| Card press feedback      | none in prototype         | Add a small `scale(0.98)` 100ms in production         |
| Last-move highlight      | fade                      | Optional 150ms fade-in on the copper square overlay   |
| Horizontal "Continúa" scroll | native momentum       | iOS deceleration normal                              |

No gestures beyond tap & scroll in the prototype. In production consider:
- Swipe left/right on the board to step through moves
- Long-press a move in the list to "set as bookmark"

---

## State Management

Minimal — for the three screens prototyped:

```ts
type AppState = {
  tab: 'home' | 'library' | 'practice';     // bottom tab
  openingId: string | null;                  // null = on a tab; set = in Detail
  libraryFilter: 'all' | 'open' | 'semi-open' | 'closed' | 'indian' | 'flank';
};

type DetailState = {
  ply: number;        // 0..opening.moves.length
  playing: boolean;
};
```

For a real app, persist:
- `progress[openingId]` → `{ pliesViewed: number, completed: boolean, lastViewedAt: ISO }`
- `streakDays`, `lastOpenedDate`
- `dailyOpeningId` (rotated daily)

---

## Data model

The canonical opening dataset is in `openings.jsx` and should be copied as-is into a `openings.ts` / `openings.json`. Schema:

```ts
type Move = {
  from: string;     // e.g. 'e2'
  to: string;       // e.g. 'e4'
  san: string;      // Spanish algebraic, e.g. 'Cf3', 'Ab5', 'cxd4'
  note: string;     // Spanish commentary, 1-2 sentences
};

type Opening = {
  id: string;                 // 'ruy-lopez'
  name: string;               // 'Ruy López'
  spanish: string;            // 'Apertura Española'
  eco: string;                // 'C60–C99'
  family: 'open' | 'semi-open' | 'closed' | 'indian' | 'flank';
  familyLabel: string;        // 'Juegos abiertos'
  color: 'Blancas' | 'Negras';
  popularity: 1 | 2 | 3 | 4 | 5;
  difficulty: 'Principiante' | 'Intermedio' | 'Avanzado';
  year: number;
  tagline: string;            // one-liner
  description: string;        // history paragraph
  idea: string;               // strategic idea paragraph
  moves: Move[];              // main line, 5-9 plies
};
```

12 openings included: Ruy López, Italian, Sicilian, French, Caro-Kann, Queen's Gambit, King's Indian, London System, English, Scandinavian, Nimzo-Indian, Pirc.

**Move application**: the prototype uses a deliberately tiny custom applier (no real chess engine) that handles ordinary moves + captures only. **For production, use [`chess.js`](https://github.com/jhlywa/chess.js)** to validate moves, support castling/en-passant/promotion, and generate FEN/PGN. Convert each `{from, to}` to a SAN move via `chess.move({from, to})`. The commentary stays as authored Spanish text.

---

## Assets
- **Google Fonts**: EB Garamond, Inter, JetBrains Mono. Self-host these in production for offline + performance.
- **Chess pieces**: prototype uses Unicode glyphs. Replace with an SVG set in production (suggested: [cburnett](https://github.com/lichess-org/lila/tree/master/public/piece/cburnett) — CC-BY-SA-3.0 — or commission a custom set for brand consistency).
- **Icons**: all bespoke inline SVG. No external icon library.
- **Imagery**: none — the design is intentionally typography-and-board-driven.

---

## Files in this bundle

| File              | Purpose                                                                 |
|-------------------|-------------------------------------------------------------------------|
| `index.html`      | Entry point — loads fonts, React, Babel, and the four JSX modules.      |
| `app.jsx`         | Top-level router (tabs + opening detail).                               |
| `screens.jsx`     | `HomeScreen`, `LibraryScreen`, `DetailScreen`, `PracticeScreen`, plus shared chrome (TabBar, TopBar, Chip, Popularity, ColorDot, SectionLabel). |
| `chess-board.jsx` | `ChessBoard`, `MiniBoard`, piece glyphs, `applyMove`, `piecesAfter`.   |
| `openings.jsx`    | **The opening dataset** — copy this content into your data layer.        |
| `ios-frame.jsx`   | Decorative iOS device shell used only for the prototype. **Discard** in a real iOS app; in a web app keep only if you want the same framed presentation. |

---

## Implementation checklist

1. Copy `openings.jsx` content into your data layer as JSON or TS.
2. Set up the design tokens (colors, fonts, type scale) in your styling system.
3. Pull in `chess.js` and build a small `ChessBoardView` component that renders an 8×8 grid + an absolutely-positioned pieces layer with transform-animated piece movement.
4. Build the three screens against the layout specs above.
5. Wire navigation: tab bar at root, push to Detail on opening tap, hide tab bar in Detail.
6. Add the auto-play timer for Detail (1100ms per move).
7. Persist progress and daily opening rotation.
8. Replace Unicode piece glyphs with SVG piece set.
9. QA in both portrait and landscape; the design is portrait-first but should scale.
10. Accessibility: ensure 4.5:1 contrast on body text (cream on `--bg` passes); add VoiceOver labels for each piece, each move list entry ("3. blanco alfil a b5"), and the play/pause control.

---

## Notes & open questions for the developer

- Move-list scrolling: in long openings (>10 plies), the move-list card should auto-scroll the current move into view.
- Family filter: in the prototype, "open" filter shows only `Juegos abiertos`. Confirm whether filter should also apply within the home screen's "Explora por familia" tap.
- "Apertura del día" rotation logic is not specified — recommend `openings[dayOfYear % openings.length]` deterministically per user.
- The `Práctica` screen is a placeholder only. Build out the three exercise modes (memory replay, identify opening, find the move) as a follow-up.
- Tablet layout: the prototype is mobile-only. For iPad/web, consider a two-pane layout (move list + board on right, history + commentary on left).
