// Main app — routing across the three screens inside an iOS frame

function App() {
  const [tab, setTab] = React.useState('home');
  const [openingId, setOpeningId] = React.useState(null);
  const [filter, setFilter] = React.useState('all');

  const opening = openingId ? OPENINGS.find(o => o.id === openingId) : null;

  const goToOpening = (id) => setOpeningId(id);
  const goBack = () => setOpeningId(null);
  const goToLibrary = () => { setOpeningId(null); setTab('library'); };

  let screen;
  if (opening) {
    screen = <DetailScreen opening={opening} goBack={goBack} />;
  } else if (tab === 'home') {
    screen = <HomeScreen goToOpening={goToOpening} goToLibrary={goToLibrary} />;
  } else if (tab === 'library') {
    screen = <LibraryScreen goToOpening={goToOpening} filter={filter} setFilter={setFilter} />;
  } else {
    screen = <PracticeScreen />;
  }

  return (
    <IOSDevice width={402} height={874} dark={true}>
      <div style={{ position: 'relative', height: '100%', background: 'var(--bg)' }}>
        {/* Top padding for the status bar (50px area inside IOSDevice) */}
        <div style={{ height: 54 }} />

        {/* Scrolling area */}
        <div className="scroll" style={{
          position: 'absolute', top: 54, left: 0, right: 0, bottom: 0,
          overflowY: 'auto',
        }}>
          {screen}
        </div>

        {/* Bottom tab bar (hidden when in detail) */}
        {!opening && <TabBar tab={tab} setTab={setTab} />}
      </div>
    </IOSDevice>
  );
}

ReactDOM.createRoot(document.getElementById('root')).render(<App />);
